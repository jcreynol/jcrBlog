---
title: "Cover Post Example"
date: 2018-05-28T14:09:24+07:00
draft: false
type: "post"
cover: "/img/cover.jpg"
---

# Cover post example
Cover post example